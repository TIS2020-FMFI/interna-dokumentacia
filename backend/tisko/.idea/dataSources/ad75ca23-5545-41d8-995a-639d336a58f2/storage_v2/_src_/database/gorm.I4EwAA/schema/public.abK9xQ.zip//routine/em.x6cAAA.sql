create function em() returns integer
    language sql
as
$$
SELECT 50
$$;

alter function em() owner to postgres;

