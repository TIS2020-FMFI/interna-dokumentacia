create function em() returns integer
    language sql
as
$$
SELECT 10
$$;

alter function em() owner to postgres;

