create function tr() returns integer
    language sql
as
$$
SELECT 50
$$;

alter function tr() owner to postgres;

