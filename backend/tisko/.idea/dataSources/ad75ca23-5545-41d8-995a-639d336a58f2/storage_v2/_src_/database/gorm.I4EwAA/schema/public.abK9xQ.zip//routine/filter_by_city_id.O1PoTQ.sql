create function filter_by_city_id(id_c integer) returns SETOF employees
    language plpgsql
as
$$
declare
    c  cities;
    r_Return employees%rowtype;

begin
    SELECT * FROM cities where cities.id=id_c INTO c;
    for r_Return in select * from employees e
                    where  e.department_id=c.id
        loop
            return next r_Return;
        end loop;
    return ;
end
$$;

alter function filter_by_city_id(integer) owner to postgres;

