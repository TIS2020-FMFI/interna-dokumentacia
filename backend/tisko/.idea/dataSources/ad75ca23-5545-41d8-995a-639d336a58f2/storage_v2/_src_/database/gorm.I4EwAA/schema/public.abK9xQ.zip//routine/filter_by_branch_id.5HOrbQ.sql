create function filter_by_branch_id(id_b integer) returns SETOF employees
    language plpgsql
as
$$
declare
    b    branches;
    r_Return employees%rowtype;

begin
    SELECT * FROM branches where branches.id=id_b INTO b;
    for r_Return in select * from employees e
                    where  e.branch_id=b.id and e.deleted=false
        loop
            return next r_Return;
        end loop;
    return ;
end
$$;

alter function filter_by_branch_id(integer) owner to postgres;

