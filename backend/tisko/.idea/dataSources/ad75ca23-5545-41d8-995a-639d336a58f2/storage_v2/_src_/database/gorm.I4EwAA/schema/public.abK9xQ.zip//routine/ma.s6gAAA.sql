create function ma() returns integer
    language sql
as
$$
SELECT 10
$$;

alter function ma() owner to postgres;

