create function tr() returns integer
    language sql
as
$$
SELECT 100
$$;

alter function tr() owner to postgres;

