create function de() returns integer
    language sql
as
$$
SELECT 3
$$;

alter function de() owner to postgres;

