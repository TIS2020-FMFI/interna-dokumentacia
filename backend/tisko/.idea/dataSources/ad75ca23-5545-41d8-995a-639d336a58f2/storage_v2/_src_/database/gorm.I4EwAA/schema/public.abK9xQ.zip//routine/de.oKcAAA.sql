create function de() returns integer
    language sql
as
$$
SELECT 5
$$;

alter function de() owner to postgres;

