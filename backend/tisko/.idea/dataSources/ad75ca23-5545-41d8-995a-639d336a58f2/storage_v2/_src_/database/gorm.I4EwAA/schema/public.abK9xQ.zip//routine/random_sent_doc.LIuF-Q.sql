create function random_sent_doc() returns integer
    language sql
as
$$
SELECT id
from documents
where edited = false
order by random()
limit 1
$$;

alter function random_sent_doc() owner to postgres;

