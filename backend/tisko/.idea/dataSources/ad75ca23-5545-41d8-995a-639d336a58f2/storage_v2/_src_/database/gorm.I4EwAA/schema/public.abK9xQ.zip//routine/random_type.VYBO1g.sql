create function random_type() returns character varying
    language sql
as
$$
SELECT case random(4)
           when 1 then 'TPK'
           when 2 then 'OS'
           when 3 then 'PP'
           when 4 then 'PL' end as type
$$;

alter function random_type() owner to postgres;

