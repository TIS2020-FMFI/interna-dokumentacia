create function random_timestamp() returns timestamp without time zone
    language sql
as
$$
SELECT random() * (current_timestamp - timestamp '2017-01-01') + timestamp '2017-01-01'
$$;

alter function random_timestamp() owner to postgres;

