create function random(num integer) returns integer
    language sql
as
$$
SELECT floor(random() * num)::integer + 1
$$;

alter function random(integer) owner to postgres;

