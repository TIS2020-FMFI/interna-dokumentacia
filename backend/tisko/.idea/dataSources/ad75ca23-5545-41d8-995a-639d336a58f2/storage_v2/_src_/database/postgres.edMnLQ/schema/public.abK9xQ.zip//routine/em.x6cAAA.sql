create function em() returns integer
    language sql
as
$$
SELECT 600
$$;

alter function em() owner to postgres;

