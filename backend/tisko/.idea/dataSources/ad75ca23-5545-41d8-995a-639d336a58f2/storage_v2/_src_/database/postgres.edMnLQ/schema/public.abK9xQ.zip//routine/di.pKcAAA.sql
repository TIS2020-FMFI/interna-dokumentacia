create function di() returns integer
    language sql
as
$$
SELECT 30
$$;

alter function di() owner to postgres;

