create function ci() returns integer
    language sql
as
$$
SELECT 3
$$;

alter function ci() owner to postgres;

