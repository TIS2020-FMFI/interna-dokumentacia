create function ci() returns integer
    language sql
as
$$
SELECT 5
$$;

alter function ci() owner to postgres;

