create function filter_by_department_id(id_d integer) returns SETOF employees
    language plpgsql
as
$$
declare
    d  departments;
    r_Return employees%rowtype;

begin
    SELECT * FROM departments where departments.id=id_d INTO d;
    for r_Return in select * from employees e
                    where  e.department_id=d.id
        loop
            return next r_Return;
        end loop;
    return ;
end
$$;

alter function filter_by_department_id(integer) owner to postgres;

