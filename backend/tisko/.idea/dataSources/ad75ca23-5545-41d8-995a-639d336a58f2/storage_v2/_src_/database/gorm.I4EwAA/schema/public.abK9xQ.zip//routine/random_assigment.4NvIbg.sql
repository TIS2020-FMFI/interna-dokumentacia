create function random_assigment() returns character varying
    language sql
as
$$
SELECT '' || floor(random(br())) || '; ' || -- branch
       floor(random(ci())) || '; ' || -- city
       floor(random(de())) || '; ' || -- department
       floor(random(di())) -- division
$$;

alter function random_assigment() owner to postgres;

