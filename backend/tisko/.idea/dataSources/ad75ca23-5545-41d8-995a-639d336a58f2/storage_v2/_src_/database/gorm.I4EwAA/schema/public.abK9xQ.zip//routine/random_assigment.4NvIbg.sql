create function random_assigment() returns character varying
    language sql
as
$$
SELECT '' || floor(random() * 5) + 1  || ','  ||  -- branch
       '' || floor(random() * 15) + 1 || ','  ||  --
       '' || floor(random() * 30) + 1 || ','  ||  -- department
       '' || floor(random() * 10) + 1             -- city
$$;

alter function random_assigment() owner to postgres;

