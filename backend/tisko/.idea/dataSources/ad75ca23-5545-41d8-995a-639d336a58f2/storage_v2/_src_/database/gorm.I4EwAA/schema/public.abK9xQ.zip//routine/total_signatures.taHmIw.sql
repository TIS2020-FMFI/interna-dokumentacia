create function total_signatures() returns integer
    language sql
as
$$
SELECT (em()*doc())::integer
$$;

alter function total_signatures() owner to postgres;

