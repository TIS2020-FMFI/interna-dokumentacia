create function ci() returns integer
    language sql
as
$$
SELECT 10
$$;

alter function ci() owner to postgres;

