create function is_suitable(id1 integer, id2 integer) returns boolean
    language plpgsql
as
$$
begin
    return (id1 = id2 or id1 isnull or id2 isnull or id2 = 0);
end;
$$;

alter function is_suitable(integer, integer) owner to postgres;

