create function de() returns integer
    language sql
as
$$
SELECT 15
$$;

alter function de() owner to postgres;

