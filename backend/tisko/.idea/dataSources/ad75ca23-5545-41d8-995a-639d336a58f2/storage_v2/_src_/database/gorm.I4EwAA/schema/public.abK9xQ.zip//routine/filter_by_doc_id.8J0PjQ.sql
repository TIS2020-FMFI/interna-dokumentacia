create function filter_by_doc_id(id_doc integer) returns SETOF employees
    language plpgsql
as
$$
declare
    d    documents;
    r_Return employees%rowtype;

begin
    SELECT * FROM documents where documents.id =id_doc INTO d ;
    for r_Return in select * from employees e
                    where (d.branch_id is null or e.branch_id=d.branch_id)
                      and (d.division_id is null or e.division_id=d.division_id)
                      and (d.department_id is null or e.department_id=d.department_id)
                      and (d.city_id is null or e.city_id=d.city_id)
        loop
            return next r_Return;
        end loop;
    return ;
end
$$;

alter function filter_by_doc_id(integer) owner to postgres;

