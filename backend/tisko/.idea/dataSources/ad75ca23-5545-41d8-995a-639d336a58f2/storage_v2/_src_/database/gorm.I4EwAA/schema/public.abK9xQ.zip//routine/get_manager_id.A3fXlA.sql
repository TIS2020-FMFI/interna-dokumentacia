create function get_manager_id(e_id integer) returns integer
    language sql
as
$$
SELECT manager_id
FROM employees
WHERE employees.id = e_id
$$;

alter function get_manager_id(integer) owner to postgres;

