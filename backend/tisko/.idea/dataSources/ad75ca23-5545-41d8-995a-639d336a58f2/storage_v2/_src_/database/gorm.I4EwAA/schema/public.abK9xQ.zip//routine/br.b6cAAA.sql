create function br() returns integer
    language sql
as
$$
SELECT 5
$$;

alter function br() owner to postgres;

