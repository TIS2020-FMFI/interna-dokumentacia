create function br() returns integer
    language sql
as
$$
SELECT 3
$$;

alter function br() owner to postgres;

