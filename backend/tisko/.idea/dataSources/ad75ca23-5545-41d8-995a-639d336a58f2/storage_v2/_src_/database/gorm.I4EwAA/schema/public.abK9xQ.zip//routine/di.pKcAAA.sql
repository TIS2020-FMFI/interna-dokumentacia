create function di() returns integer
    language sql
as
$$
SELECT 3
$$;

alter function di() owner to postgres;

