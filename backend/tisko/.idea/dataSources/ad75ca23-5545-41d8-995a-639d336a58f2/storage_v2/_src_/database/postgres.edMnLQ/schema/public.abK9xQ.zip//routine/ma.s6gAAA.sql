create function ma() returns integer
    language sql
as
$$
SELECT 30
$$;

alter function ma() owner to postgres;

