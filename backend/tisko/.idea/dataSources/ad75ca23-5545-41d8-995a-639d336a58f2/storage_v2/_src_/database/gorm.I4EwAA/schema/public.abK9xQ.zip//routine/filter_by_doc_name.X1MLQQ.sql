create function filter_by_doc_name(name0 character varying) returns SETOF employees
    language plpgsql
as
$$
declare
    d    documents;
    r_Return employees%rowtype;

begin
    SELECT * FROM documents where documents.name = name0 INTO d ;
    for r_Return in select * from filter_by_doc_id(d.id)
        loop
            return next r_Return;
        end loop;
    return ;
end
$$;

alter function filter_by_doc_name(varchar) owner to postgres;

