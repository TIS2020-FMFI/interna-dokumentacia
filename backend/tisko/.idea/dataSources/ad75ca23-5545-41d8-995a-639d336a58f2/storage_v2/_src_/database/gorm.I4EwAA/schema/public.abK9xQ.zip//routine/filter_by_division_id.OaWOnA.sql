create function filter_by_division_id(id_d integer) returns SETOF employees
    language plpgsql
as
$$
declare
    d  divisions;
    r_Return employees%rowtype;

begin
    SELECT * FROM divisions where divisions.id=id_d INTO d;
    for r_Return in select * from employees e
                    where  e.division_id=d.id
        loop
            return next r_Return;
        end loop;
    return ;
end
$$;

alter function filter_by_division_id(integer) owner to postgres;

