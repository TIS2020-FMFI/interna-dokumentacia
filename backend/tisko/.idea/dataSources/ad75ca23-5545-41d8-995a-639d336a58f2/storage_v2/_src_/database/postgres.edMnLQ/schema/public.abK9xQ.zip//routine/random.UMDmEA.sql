create function random(num integer) returns integer
    language sql
as
$$
SELECT (floor(random() * num) + 1)::integer
$$;

alter function random(integer) owner to postgres;

