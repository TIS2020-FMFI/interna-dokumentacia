create function doc() returns integer
    language sql
as
$$
SELECT 100
$$;

alter function doc() owner to postgres;

