create function doc() returns integer
    language sql
as
$$
SELECT 50
$$;

alter function doc() owner to postgres;

